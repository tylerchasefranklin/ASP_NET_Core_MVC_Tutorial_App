﻿using Microsoft.AspNetCore.Mvc;

namespace tyler_franklin_finalproject.Areas.Help.Controllers
{
    [Area("Help")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
