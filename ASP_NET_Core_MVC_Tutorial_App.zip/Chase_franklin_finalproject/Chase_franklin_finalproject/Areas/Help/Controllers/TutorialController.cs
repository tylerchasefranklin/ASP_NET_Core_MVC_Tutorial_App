﻿using Microsoft.AspNetCore.Mvc;

namespace tyler_franklin_finalproject.Areas.Help.Controllers
{
    [Area("Help")]
    public class TutorialController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [Route("[action]")]
        public IActionResult Page1()
        {
            return View();
        }

        [Route("[action]")]
        public IActionResult Page2()
        {
            return View();
        }

        [Route("[action]")]
        public IActionResult Page3()
        {
            return View();
        }
    }
}
